Cosmic Zoom / 코스믹 줌 — press kit

EN  From the edge of the universe to a quark, in one pinch. A free science app for kids aged 6–15:
    zoom through 44 powers of ten (10^26 m to 10^-18 m), 22 illustrated stops, missions and a size book.
    No ads, no sign-up, no internet permission. English, Korean, Japanese, Chinese.
KO  손가락 하나로 우주 끝에서 쿼크까지. 6~15세 어린이를 위한 무료 과학 앱.
    10의 44제곱(10^26 m ~ 10^-18 m), 그림으로 그린 22단계, 미션과 크기 도감.
    광고·회원가입·인터넷 권한 없음. 한국어·영어·일본어·중국어.

Web demo  https://sssnaplab.github.io/cosmic-zoom/play.html
Videos    https://youtube.com/shorts/mwvllW6_9js (EN) · rwQRhpqlCWg (KO) · CQ7IY8Peswo (JA) · KnT0HyAKaMo (ZH)
Developer SnapLab (Korea) · snaplabpresent@gmail.com
Screenshots, graphics and videos may be used freely in articles and videos about the app.
